<?php
// Initialize Variables

// Connect to the database 

include_once('server.php');

if(isset($_POST['reg_user'])){
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $fullname = mysqli_real_escape_string($db, $_POST['val-username']);
    $email = mysqli_real_escape_string($db, $_POST['val-email']);
    $suggestions = mysqli_real_escape_string($db, $_POST['val-suggestions']);
    $country = mysqli_real_escape_string($db, $_POST['val-skill']);
    $currency = mysqli_real_escape_string($db, $_POST['val-currency']);
    $number= mysqli_real_escape_string($db, $_POST['val-phoneus']);
}

$user_check_query = "SELECT * FROM verified WHERE username='$username' OR email='$email' LIMIT 1";
$result = mysqli_query($db, $user_check_query);
$user = mysqli_fetch_assoc($result);

if ($user) { // if user exists
    if ($user['username'] === $username){
        echo header('location:already.php');
        }
    }

else{
        $query = "INSERT INTO verified (username,fullname, email, suggestions, country, currency, number) 
        VALUES('$username','$fullname', '$email', '$suggestions', '$country','$currency', '$number')";
        $result = mysqli_query($db, $query);
            if ($result) {
                $sql = "INSERT INTO pcointokken(username,email,amount)VALUES('$username', '$email', '500')";
                $query_result = mysqli_query($db, $sql);
                $_SESSION['username'] = $username;
                $_SESSION['email'] = $email;
                $_SESSION['fullname'] = $fullname;
                $_SESSION['suggestions'] = $suggestions;
                $_SESSION['country'] = $country;
                echo header("location:success.php");
    }

}