<?php include('server.php');
$email    = "";
$errors = array();
if (isset($_POST['reset'])) {
  $email = mysqli_real_escape_string($db, $_POST['email']);
  

  if (empty($email)) {
  	array_push($errors, "Your Email is required");
  }
  if (count($errors) == 0) {
    $query = "SELECT * FROM users WHERE email='$email' ";
    $results = mysqli_query($db, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['email'] = $email;
      ini_set( 'display_errors', 1 );
      error_reporting( E_ALL );
      $from = "epoltech@e-poltechsolutions.com";
      $to = $_SESSION['email'];
      $subject = "Password Reset Link.";
      $message = "Your Password Reset link is https://poltechsolutionsllc.com/forgotpas.php?password=$email
           ";
      $headers = "From:" . $from;
      if(mail($to,$subject,$message, $headers)) {
          $email = $_SESSION['email'];
          echo"<p  align = 'center' style='color:green'><strong>Reset Email Sent!!</strong></style>
                    <script type='text/javascript'>
                    window.location = 'login.php';
                    </script> 
                    ";
        }
    }
      else{
        array_push($errors, "Wrong Email, The Email is  associated with any user account");
      }
       
    }
}

?>