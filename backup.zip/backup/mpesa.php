<?php 
  include('server.php');

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }

  if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['username']);
	header("location: login.php");
} 

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <META http-equiv="Content-Type" content="text/html; charset= ISO-8859-1">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="logo.png">
    <title>P-Coin Wallet Investment </title>
    <!-- Custom CSS -->
    
    <link href="css/lib/amchart/export.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
</head>

<body  onload="getLocation()"class="header-fix fix-sidebar">
    
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <!-- header header  -->
        <div class="header">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <!-- Logo -->
                <div class="navbar-header">
        
                        <!-- Logo icon -->
                        <b><img src="coin3.png" alt="homepage" class="dark-logo" /></b>
                        <!--End Logo icon -->
                        <!-- Logo text -->
                        <span><img src="images/P-Coin(1).png" alt="homepage" class="dark-logo" /></span>
                    </a>
                </div>
                <!-- End Logo -->
                <div class="navbar-collapse">
                    <!-- toggle and nav items -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link toggle-nav hidden-md-up text-muted  " href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                        <li class="nav-item m-l-10"> <a class="nav-link sidebartoggle hidden-sm-down text-muted  " href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <!-- Messages -->
                        <li class="nav-item dropdown mega-menu"> <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="ti-wallet m-r-5"></i> Wallet</a>

                            <div class="dropdown-menu animated slideInDown">
                                <ul class="mega-menu-menu row">
                                </ul>
                            </div>
                        </li>
                        <!-- End Messages -->
                    </ul>
                    <!-- User profile and search -->
                    <ul class="navbar-nav my-lg-0">
                        <!-- Comment -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-bell"></i>
								<div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
							</a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated slideInRight">
                                <ul>
                                    <li>
                                        <div class="drop-title">Notifications</div>
                                    </li>
                                    <li>
                                        <div class="header-notify">
                                            <!-- Message -->
                                            <a href="#">
                                                <i class="#" title="#"></i>
                                                <div class="notification-contnet">
                                                    <h5>Empty</h5> <span class="mail-desc">Sorry No Content Here!!</span> 
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> Check all notifications <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Comment -->
                        <!-- Messages -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" id="2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-envelope"></i>
								<div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
							</a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated slideInRight" aria-labelledby="2">
                                <ul>
                                    <li>
                                        <div class="drop-title">You have 1 new messages</div>
                                    </li>
                                    <li>
                                        <div class="header-notify">
                                            <!-- Message -->
                                            <a href="#">
                                                
                                                <div class="notification-contnet">
                                                    <h5>Max</h5> <span class="mail-desc"><strong><?php echo $_SESSION['username'];?></strong>: Welcome To P-Coin Investment Wallet Cant wait to have you started in this.</span> 
                                                </div>
                                            </a>
                                            
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> See all e-Mails <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Messages -->
                        <!-- Profile -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user"></i></a>
                            <div class="dropdown-menu dropdown-menu-right animated slideInRight">
                                <ul class="dropdown-user">
                                    <li role="separator" class="divider"></li>
									<?php  if (isset($_SESSION['username'])) : ?>
    	                            <p style="color:Green;">Welcome!:<strong><?php echo $_SESSION['username']; ?></strong></p>
                                    <li><a> Profile</a></li>
									<li><a> Name:<?php echo $_SESSION['username']; ?></a></li>
									<li><a> Email:  <?php
                    $user_check_query = "SELECT * FROM users WHERE username='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['email'] === 0){echo   '$0.0' ;} else { echo $row['email']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    ?></a> </li>

                                    <li><a href="#">

									</a></li>
                                    <li><a href="#"> Inbox</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a href="userprofile.php"> Profile Setting</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a a href="index.php?logout='1'" style="color: red;"> Logout</a>
									
    <?php endif ?>
								</li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- End header header -->
        <!-- Left Sidebar  -->
        <div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebar-menu">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a class="has-arrow  " href="index.php" aria-expanded="false"><i class="fa fa-tachometer"></i><span class="hide-menu">Dashboard <span class="label label-rouded label-primary pull-right"></span></span></a>
                            <ul aria-expanded="false" class="collapse">
                             <li><a href="index.php">Home</a></li> 
                                
                            </ul>
                        </li>
                        <li class="nav-label">Teams & Pools</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-columns"></i><span class="hide-menu">Check Team</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="#">Bankers Team</a></li>
                                <li><a href="#">Riskers</a></li>
                                <li><a href="#">Intermediates</a></li>
                                
                            </ul>
                        </li>
                        <li class="nav-label">Chats &amp; Announcements </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-envelope"></i><span class="hide-menu">Mailbox</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="#">Compose</a></li>
                                <li><a href="#">Read</a></li>
                                <li><a href="#">Inbox</a></li>
                            </ul>
                        </li>
                        
                        <li class="nav-label">Features</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-suitcase"></i><span class="hide-menu">Finances <span class="label label-rouded label-danger pull-right"></span></span></a>
						<ul aria-expanded="false" class="collapse">
                                <li><a href="withdraw.php"> Request Withdrawal </a></li>
                                <li><a href="wallet.php"> Transfer Pcoin </a></li>
                                <li><a href=""> Transfer USD </a></li>
                               
                              
                            </ul>
                        </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-wpforms"></i><span class="hide-menu">Affliates</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><button style="background:#3630a3;color:white;" onclick="this.innerHTML='Check Link at the bottom of the page'">Check Your affiliate link </button></li>
                                <li><a href="#">FAQ About our Affiliates</a></li>
                              

                            
                              
                            </ul>
                        </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="ti-wallet m-r-5"></i><span class="hide-menu">Deposit</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="#">Deposit With Mpesa</a></li>
                                <li><a>

                                <div id="bp-payment-button"></div>

                                <script src="https://confirmo.net/sdk/scripts/confirmo.js"></script>
                                <script type="text/javascript">
                                Confirmo.PaymentButton.initialize({
                                    "id": "bp-payment-button",
                                    "url": "https://confirmo.net",
                                    "buttonType": "SIMPLE",
                                    "paymentButtonId": "dEoN9G4PRZlLDWYnK0wJ3mMX5qrkVx0Kvj7",
                                    "values": {
                                        "productName": "pcoin",
                                        "productDescription": null,
                                        "reference": null,
                                        "returnUrl": null,
                                        "overlay": true
                                    }
                                });
                                </script></a>                            
                               </li>
                                <li><a>

                                    <div>
                                    <a class="donate-with-crypto"
                                        href="https://commerce.coinbase.com/checkout/77b847a1-51a2-4b41-a6c3-83f727578364">
                                        Pay with Coin Base
                                    </a>
                                    <script src="https://commerce.coinbase.com/v1/checkout.js?version=201807">
                                    </script>
                                    </div>
                                </a></li>
                                <li><a href="#">Deposit With Cash App</a></li>
                                <li><a href="#">Deposit With Ethereum</a></li>
                                <li><a href="#">Deposit With MTN Money</a></li>
                            </ul>
							
                        </li>
                        <li class="nav-label">EXTRA</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-book"></i><span class="hide-menu">Start Verification<span class="label label-rouded label-success pull-right">4</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                
                                <li><a href="#" class="has-arrow">Email Vefication <span class="label label-rounded label-success">3</span></a>
                                    <ul aria-expanded="false" class="collapse">
                                        <li><a href="page-login.html">KYC Verification</a></li>
                                        <li><a href="form-validation.php">Profile Update</a></li>
									</ul>
                                </li>
                                
                            </ul>
                        </li>
                       
                        
                               
                            </ul>
                        </li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- Bread crumb -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">Dashboard</h3>
                    <?php
                    $user_check_query ="SELECT c.username, c.fullname, c.number, l.username, l.email FROM verified c INNER JOIN users l ON l.email = c.email WHERE l.username ='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['number'] === 0){echo   '<button  style="background:#FF0000;color:white;" type="button"> Status:Not Verified!</button>' ;} else { echo '<button  style="background:#008000;color:white;" type="button"> Status:Verified!</button>' ; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    ?>
                    
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
            <!-- End Bread crumb -->
            <!-- Container fluid  -->
            

                    <!-- column -->
                    <div class="col-lg-6">
                        <div class="card" align= "centre">
                            <div class="card-body">
                                <h4 class="card-title"><b>PAY WITH M-PESA</b></h4>
                                <h1>Feature Coming Soon</h1>

                                


                                
                                

                            </div>
                        </div>
                    </div>
                    <!-- column -->

                    <!-- column -->
                    
                <!-- End PAge Content -->
            </div>
            <!-- End Container fluid  -->
            <!-- footer -->
            <footer class="footer"> © 2022 P-Coin All Right Reserved.</footer>
            <!-- End footer -->
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
	
	<!-- Amchart -->
    <script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
    <script src="js/lib/chart-amchart/serial.js"></script>
    <script src="js/lib/chart-amchart/export.min.js"></script>
    <script src="js/lib/chart-amchart/light.js"></script>
    <script src="js/lib/chart-amchart/ammap.js"></script>
    <script src="js/lib/chart-amchart/worldLow.js"></script>
    <script src="js/lib/chart-amchart/pie.js"></script>
    <script src="js/lib/chart-amchart/amstock.js"></script>
    <script src="js/lib/chart-amchart/amchart-init.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>


    <script src="js/lib/weather/jquery.simpleWeather.min.js"></script>
    <script src="js/lib/weather/weather-init.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel-init.js"></script>
    <script src="js/scripts.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>

</body>

</html>