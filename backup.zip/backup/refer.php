<?php

include('server.php');

if(isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location:');
    }
if (isset($_GET['logout'])) {
        session_destroy();
        unset($_SESSION['username']);
        header("location: login.php");
      } 


if(isset($_POST['create-ref']))
{

$user=mysqli_real_escape_string($db,$_POST["user"]);
$user=htmlentities($user);

//friendly URL conversion
function to_prety_url($str){
    if($str !== mb_convert_encoding( mb_convert_encoding($str, 'UTF-32', 'UTF-8'), 'UTF-8', 'UTF-32') )
        $str = mb_convert_encoding($str, 'UTF-8', mb_detect_encoding($str));
    $str = htmlentities($str, ENT_NOQUOTES, 'UTF-8');
    $str = preg_replace('`&([a-z]{1,2})(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig);`i', '\1', $str);
    $str = html_entity_decode($str, ENT_NOQUOTES, 'UTF-8');
    $str = preg_replace(array('`[^a-z0-9]`i','`[-]+`'), '-', $str);
    $str = strtolower( trim($str, '-') );
    return $str;
}
$str=to_prety_url($user);

// sql query for inserting data into database
$sql_query = "INSERT INTO referral (user,str) VALUES ('$user','$str')" ;
$result_set=mysqli_query($db,$sql_query);

//Referral URL
$refurl="http://localhost/invest/$str"; //replace it with your URL ex: http://example.com/refer/$str

}

?>

<h2>Create Referral URL</h2>
<div class="clearfix">&nbsp;</div>
<form method="post">
<input type="text" name="user" value="<?php echo $_SESSION['username']?>" maxlength="20">
<button type="submit" name="create-ref">Create Now</button>
<br />

<?php
if(isset($_POST['user'])) {
echo "Referral URL Created - $refurl";
}
?>