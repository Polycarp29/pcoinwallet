<?php

$errors = array();
//initializing Variables.
$db = mysqli_connect('69.10.62.7', 'poltechs_admin', 'Nm643Ppq', 'poltechs_registration');
if(isset($_POST['reg_user'])){
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $wallet_id = mysqli_real_escape_string($db, $_POST['val-add']);
    $meansofpay = mysqli_real_escape_string($db, $_POST['val-skill']);
    $amount = mysqli_real_escape_string($db, $_POST['val-amount']);
  	$create_datetime = date("Y-m-d H:i:s");

$sql = "UPDATE balances SET wallet_id = '$wallet_id', meansofpay = '$meansofpay', amountb = amountb -'$amount' WHERE username ='$username' ";
mysqli_query($db, $sql);
$deductions = "UPDATE transactions  SET  amount = amount - '$amount' WHERE username = '$username' " ;
mysqli_query($db, $deductions);
$sql3 = "INSERT INTO history (username , amount , status, time, meansofpay, wallet) VALUES('$username', '$amount', 'Processed', '$create_datetime ','$meansofpay', '$wallet_id')";
mysqli_query($db,$sql3);
echo"               <script type='text/javascript'>
                    window.location = 'withdrawalsuccess.php';
                    </script> 
                    ";
                }