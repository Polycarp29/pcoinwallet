<?php include('server.php');
$user_check_query = "SELECT * FROM users WHERE username='".$_SESSION['username']."'";
$dbresult = mysqli_query($db, $user_check_query);
if($dbresult != "zero")
{
while($row = $dbresult->fetch_assoc())
	  {
					
if($row['email']){
ini_set( 'display_errors', 1 );
error_reporting( E_ALL );
$from = "noreply@poltechsolutionsllc.com";
$to = $row['email'];
$subject = "Your Verification code is.";
$otp = rand(100000, 999999);
$message = strval($otp);
$headers = "From:" . $from;
if(mail($to,$subject,$message, $headers)) {
    echo "The email message was sent.";
    $_SESSION["OTP"]=$otp;
} else {
    echo "<p>'The email message was not sent.'</p>";
   
}
}
}
}
?>