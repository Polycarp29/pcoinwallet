<?php
include_once('server.php');
if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: index.php');
}

if (isset($_GET['logout'])) {
  session_destroy();
  unset($_SESSION['username']);
  header("location: login.php");
} 

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <META http-equiv="Content-Type" content="text/html; charset= ISO-8859-1">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/C.png">
    <title>P-Coin Investment Wallet</title>
    <!-- Custom CSS -->
    
    <link href="css/style.css" rel="stylesheet">
</head>

<body class="header-fix fix-sidebar">
    
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <!-- header header  -->
        <div class="header">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <!-- Logo -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php">
                        <!-- Logo icon -->
                        <b><img src="images/logo.png" alt="homepage" class="dark-logo" /></b>
                        <!--End Logo icon -->
                        <!-- Logo text -->
                        <span><img src="images/P-Coin(1).png" alt="homepage" class="dark-logo" /></span>
                    </a>
                </div>
                <!-- End Logo -->
                <div class="navbar-collapse">
                    <!-- toggle and nav items -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link toggle-nav hidden-md-up text-muted  " href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                        <li class="nav-item m-l-10"> <a class="nav-link sidebartoggle hidden-sm-down text-muted  " href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <!-- Messages -->
                        <li class="nav-item dropdown mega-menu"> <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="ti-wallet m-r-5"></i> Wallet</a>
                            <div class="dropdown-menu animated slideInDown">
                                <ul class="mega-menu-menu row">

                                    
                                </ul>
                            </div>
                        </li>
                        <!-- End Messages -->
                    </ul>
                    <!-- User profile and search -->
                    <ul class="navbar-nav my-lg-0">
                        <!-- Comment -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-bell"></i>
								<div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
							</a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated slideInRight">
                                <ul>
                                    <li>
                                        <div class="drop-title">Notifications</div>
                                    </li>
                                    <li>
                                        <div class="header-notify">
                                            <!-- Message -->
                                            <a href="#">
                                                <i class="cc BTC m-r-10 f-s-40" title="BTC"></i>
                                                <div class="notification-contnet">
                                                    <h5>Empty</h5> <span class="mail-desc">Sorry No Content Here</span> 
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> Check all notifications <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Comment -->
                        <!-- Messages -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" id="2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-envelope"></i>
								<div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
							</a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated slideInRight" aria-labelledby="2">
                                <ul>
                                    <li>
                                        <div class="drop-title">You have 1 new messages</div>
                                    </li>
                                    <li>
                                    <div class="header-notify">
                                            <!-- Message -->
                                            <a href="#">
                                                
                                                <div class="notification-contnet">
                                                    <h5>Max</h5> <span class="mail-desc"><strong><?php echo $_SESSION['username'];?></strong>: Welcome To P-Coin Investment Wallet Cant wait to have you started in this.</span> 
                                                </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> See all e-Mails <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Messages -->
                        <!-- Profile -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user"></i></a>
                            <div class="dropdown-menu dropdown-menu-right animated slideInRight">
                                <ul class="dropdown-user">
                                    <li role="separator" class="divider"></li>
                                    <li><a href="#"> Profile</a></li>
                                    <li><a> Name:<?php echo $_SESSION['username']; ?></a><li>
                                    <li><a href="#"> Email :<?php
                    $user_check_query = "SELECT * FROM users WHERE username='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['email'] === 0){echo   '$0.0' ;} else { echo $row['email']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    ?></a> </li></a></li>
                                    <li><a href="#">Email</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a href="#">Profile Setting</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a href="#"> Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- End header header -->
        <!-- Left Sidebar  -->
        <div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebar-menu">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-tachometer"></i><span class="hide-menu">Dashboard <span class="label label-rouded label-primary pull-right">1</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="index.php">Home </a></li>
                            </ul>
                        </li>
                        <li class="nav-label">Teams & Pools</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-columns"></i><span class="hide-menu">Check Team</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="#">Bankers Team</a></li>
                                <li><a href="#">Riskers</a></li>
                                <li><a href="#">Intermediates</a></li>
                                
                            </ul>
                        </li>
                        <li class="nav-label">Chats &amp; Announcements </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-envelope"></i><span class="hide-menu">Mailbox</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="#">Compose</a></li>
                                <li><a href="#">Read</a></li>
                                <li><a href="#">Inbox</a></li>
                            </ul>
                        </li>
                        
                        <li class="nav-label">Features</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-suitcase"></i><span class="hide-menu">Finances <span class="label label-rouded label-danger pull-right"></span></span></a>
						<ul aria-expanded="false" class="collapse">
                                
                               
                              
                            </ul>
                        </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-wpforms"></i><span class="hide-menu">Affliates</span></a>
                            <ul aria-expanded="false" class="collapse">
                                
                               
                              
                            </ul>
                        </li>
                        
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="ti-wallet m-r-5"></i><span class="hide-menu">Deposit</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="#">Add Money</a></li>
                            </ul>
							<ul aria-expanded="false" class="collapse">
                                <li><a href="#">Widthdraw</a></li>
                            </ul>
                        </li>
                        <li class="nav-label">EXTRA</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-book"></i><span class="hide-menu">Start Verification<span class="label label-rouded label-success pull-right">4</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                
                                <li><a href="#" class="has-arrow">Email Vefication <span class="label label-rounded label-success">3</span></a>
                                    <ul aria-expanded="false" class="collapse">
                                      
                                        <li><a href="form-validation.php">Profile Update</a></li>
									</ul>
                                </li>
                                
                            </ul>
                        </li>
                       
                        
                               
                            </ul>
                        </li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- Bread crumb -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">Dashboard</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
            <script type="text/javascript">
function validate()
{
 var error="";
 var name = document.getElementById( "val-email" );
 if( name.value == "" )
 {
  error = " You have to type your Wallet Address. ";
  document.getElementById( "error_para" ).innerHTML = error;
  return false;
 }

 var password = document.getElementById( "val-currency" );
 if( password.value == "" || password.value >1000 )
 {
  error = " You Exceed the limit amount to be withdrawn per day You risk being blocked!!. ";
  document.getElementById( "error_para" ).innerHTML = error;
  return false;
 }
 var amount = document.getElementById( "amount" );
 if( amount.value == "" || amount.value < 100)
 {
  error = " You cannot Send what you dont have Ok!!!!. Minimum Amount You can send is 100  ";
  document.getElementById( "error_para" ).innerHTML = error;
  return false;
 }
 var error="";
 var name = document.getElementById( "val-currency" );
 if( name.value == "" )
 {
  error = " Your Amount Feild is empty. ";
  document.getElementById( "error_para" ).innerHTML = error;
  return false;
 }
 else
 {
  return true;
 }
}

</script>
 <?php
                if(isset($_POST['send'])){
                    $amount = mysqli_real_escape_string($db, $_POST['amount']);
                    $email = mysqli_real_escape_string($db, $_POST['email']);
                

                $user_check_amount = "SELECT * FROM pcointokken WHERE username='".$_SESSION['username']."' OR amount='$amount' LIMIT 1";
                $result = mysqli_query($db, $user_check_amount);
                $user = mysqli_fetch_assoc($result);
                $username = $_SESSION['username'];
                if ($user) { // if user amount is less than 1
                    if ($user['amount'] <1) {
                      echo"<style='color:red'><strong>You cant send What You Dont Have</strong></style>";
                    }

                }
                    // deduct from your amount 
                    $deductions = "UPDATE pcointokken  SET  amount = amount - '$amount' WHERE username = '".$_SESSION['username']."' " ;
                    mysqli_query($db, $deductions);
                    //add to the recieving account
                    $query = "UPDATE pcointokken  SET  amount = amount + '$amount' WHERE email = '$email' ";
                    mysqli_query($db, $query);
                    echo"<p  align = 'center' style='color:green'><strong>Transaction Successfull</strong></style>
                    <script type='text/javascript'>
                    window.location = 'index.php'
                    ;
                    </script> 
                    ";
                   $from = "pcoin@poltechsolutionsllc.com";
                   $to = $email;
                   $subject = "PCOIN COMING.";
                   $message = "
                   Howdy,
                   ₱₵$amount Has been Credited By $username in Your Account Check Your Wallet Balance  
                         ";
                   $headers = "From:" . $from;
                   if(mail($to,$subject,$message, $headers)) {
                      }
                 }
 ?>










            <!-- End Bread crumb -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-body">    


                                <div class="form-validation">
                                <h3 class="card-title m-t-15">SEND YOUR P-COIN</h3>
    
                                    <form class="form-valide" action=""  onsubmit="return validate();" method="post" >
                                    <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-username">Your Username <span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="val-username" name="username" value="<?php echo $_SESSION['username'];?>" readonly>
                                                <span style="color:red">Your Username: <?php echo $_SESSION['username'];?> Cannot be Altered</span>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Wallet_ID/Address <span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="val-email" name="email" placeholder="Your valid address or ID">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Total P-Coin Balance <span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="amount" name="val-amount" placeholder = "₱₵"value="<?php
									$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, pcointokken.amount From users INNER JOIN pcointokken ON users.username = pcointokken.username WHERE users.username='".$_SESSION['username']."'";
									$dbresult = mysqli_query($db,$sql);
									if($dbresult != "zero")
									{
										while($row = $dbresult->fetch_assoc())
										{
			
										if($row['amount'] ===0){echo   '0.000' ;} else { echo $row['amount']; }

										}
									}
									else
										{
										echo $dbresult;}
									?>"readonly>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">Wallet Type<span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <select class="form-control" id="val-skill" name="val-skill">
                                                    <option value="0">Please select</option>
                                                <option selected="" value="Bitcoin">P-Coin Wallet</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-currency">Amount<span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="number" class="form-control" id="val-currency" name="amount" placeholder="₱₵">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label"><a data-toggle="modal" data-target="#modal-terms" href="#">Terms &amp; Conditions</a> <span class="text-danger">*</span></label>
                                            <div class="col-lg-8">
                                                <label class="css-control css-control-primary css-checkbox" for="val-terms">
                                                                                        <input type="checkbox" class="css-control-input" id="val-terms" name="val-terms" value="1">
                                                                                        <span class="css-control-indicator"></span> I agree to the terms
                                                                                    </label>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-lg-8 ml-auto">
                                                <button type="submit" class="btn btn-primary" name='send'>Send Pcoins</button>

                                            </div>
                                        </div>
                                    </form>
                                    <p style="color:red" id="error_para" ></p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End PAge Content -->
            </div>
            <!-- End Container fluid  -->
            <!-- footer -->
            <footer class="footer"> © 2022 P-Coin All Right Reserved.</footer>
            <!-- End footer -->
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <script src="jquery-3.2.1.min.js"></script>
    <script src="script.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>


    <!-- Form validation -->
    <script src="js/lib/form-validation/jquery.validate.min.js"></script>
    <script src="js/lib/form-validation/jquery.validate-init.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>

</body>

</html>