<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>P-Coin Investment Wallet Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <META http-equiv="Content-Type" content="text/html; charset= ISO-8859-1">
  <meta name="description" content="p-coin investment wallet">
  <meta name="keywords" content="Better financial solutions , better world of infinite opportunities">
  <link rel="icon" type="image/png" sizes="16x16" href="logo.png">
  <link rel="stylesheet" type="text/css" href="style.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
<div class="banner">
    <div class="banner__content">
      <div class="banner__text">
        <strong>Reminder:</strong> Download The Pcoin Wallet Investment App <a href = "https://files.appsgeyser.com/pcoin%20wallet_15947507.apk">Here</a> Click the Close button if you already have the App .
      </div>
      <button class="banner__close" type="button">
        <span class="material-icons">
          close
        </span>
      </button>
    </div>
  </div>
  <style>
html,
body {
  margin: 0;
}

.banner {
  background: #000066;
}

.banner__content {
  padding: 16px;
  max-width: 500px;
  margin: 0 auto;
  display: flex;
  align-items: center;
}

.banner__text {
  flex-grow: 1;
  line-height: 1.4;
  font-family: "Quicksand", sans-serif;
}

.banner__close {
  background: none;
  border: none;
  cursor: pointer;
}

.banner__text,
.banner__close > span {
  color: #ffffff;
}


		
	</style>
<script>
document.querySelector(".banner__close").addEventListener("click", function () {
  this.closest(".banner").style.display = "none";
});


</script>
  <div class="header">
  	<h2>P-Coin Login</h2>
  </div>
	 
  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Username</label>
  		<input type="text" name="username" >
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="password">
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
  	<p>
  		Not yet a member? <a href="register.php">Sign up</a>
		                  <a href ="reset.php">Forgot Password?</a>
  	</p>
  </form>
   <script>
        var isNS = (navigator.appName == "Netscape") ? 1 : 0;
        if(navigator.appName == "Netscape") document.captureEvents(Event.MOUSEDOWN||Event.MOUSEUP);
        function mischandler(){
        return false;
        }
        function mousehandler(e){
        var myevent = (isNS) ? e : event;
        var eventbutton = (isNS) ? myevent.which : myevent.button;
        if((eventbutton==2)||(eventbutton==3)) return false;
        }
        document.oncontextmenu = mischandler;
        document.onmousedown = mousehandler;
        document.onmouseup = mousehandler;
        </script>
  <!--  ABOUT AREA END  -->
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
    var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
    s1.async=true;
    s1.src='https://embed.tawk.to/61ed2e7a9bd1f31184d8d464/1fq37r4a3';
    s1.charset='UTF-8';
    s1.setAttribute('crossorigin','*');
    s0.parentNode.insertBefore(s1,s0);
    })();
    </script>

</body>

         
</html>