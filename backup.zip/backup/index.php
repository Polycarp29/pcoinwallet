<?php 
  include('server.php');

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }

  if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['username']);
	header("location: login.php");
} 
$username = $_SESSION['username'];
$ip = $_SERVER['REMOTE_ADDR'];
$user_check_query = "SELECT * FROM users WHERE username='".$_SESSION['username']."'";
$dbresult = mysqli_query($db, $user_check_query);
if($dbresult != "zero")
{
while($row = $dbresult->fetch_assoc())
	  {
					
if($row['email']){
ini_set( 'display_errors', 1 );
error_reporting( E_ALL );
$from = "epoltech@e-poltechsolutions.com";
$to = $row['email'];
$subject = "DID YOU TRY TO LOGIN?.";
$message = "
Wallet Login 
Hello $username
Did You Try Login in Your Account Wallet
The IP is : $ip
We Value Your Privacy And Safety for your Money 
If you did not  Login to your Account and Reset Your Account password.
   ";
$headers = "From:" . $from;
if(mail($to,$subject,$message, $headers)) {
} else {
   
}
}
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <META http-equiv="Content-Type" content="text/html; charset= ISO-8859-1">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="p-coin investment wallet">
    <meta name="keywords" content="Better financial solutions , better world of infinite opportunities">
    <meta name="description" content="Earn from the comfort of your home with the best Investment wallet , Get awarded free pcoins on signup and kyc verifications . Lets Make money with the best networking web app.">
    <meta name="author" content="Max">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/logo.png">
    <title>P-Coin Wallet Investment </title>
    <!-- Custom CSS -->
    
    <link href="css/lib/amchart/export.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>




<body  onload="getLocation()"class="header-fix fix-sidebar">
    
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <!-- header header  -->
        <div class="header">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <!-- Logo -->
                <div class="navbar-header">
                  <a class="navbar-brand" href="index.php">
                        <!-- Logo icon -->
                        <b><img src="images/logo.png" alt="homepage" class="dark-logo" /></b>
                        <!--End Logo icon -->
                        <!-- Logo text -->
                        <span><img src="images/P-Coin(1).png" alt="homepage" class="dark-logo" /></span>
                    </a>
         				
                </div>
                <!-- End Logo -->
                <div class="navbar-collapse">
                    <!-- toggle and nav items -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link toggle-nav hidden-md-up text-muted  " href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                        <li class="nav-item m-l-10"> <a class="nav-link sidebartoggle hidden-sm-down text-muted  " href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <!-- Messages -->
                        <li class="nav-item dropdown mega-menu"> <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="ti-wallet m-r-5"></i> Wallet</a>

                            <div class="dropdown-menu animated slideInDown">
                                <ul class="mega-menu-menu row">
                                </ul>
                            </div>
                        </li>
                        <!-- End Messages -->
                    </ul>
                    <!-- User profile and search -->
                    <ul class="navbar-nav my-lg-0">
                        <!-- Comment -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-bell"></i>
								<div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
							</a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated slideInRight">
                                <ul>
                                    <li>
                                        <div class="drop-title">Notifications</div>
                                    </li>
                                    <li>
                                        <div class="header-notify">
                                            <!-- Message -->
                                            <a href="#">
                                                <i class="#" title="#"></i>
                                                <div class="notification-contnet">
                                                    <h5>Empty</h5> <span class="mail-desc">Sorry No Content Here!!</span> 
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> Check all notifications <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Comment -->
                        <!-- Messages -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" id="2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-envelope"></i>
								<div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
							</a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated slideInRight" aria-labelledby="2">
                                <ul>
                                    <li>
                                        <div class="drop-title">You have 1 new messages</div>
                                    </li>
                                    <li>
                                        <div class="header-notify">
                                            <!-- Message -->
                                            <a href="#">
                                                
                                                <div class="notification-contnet">
                                                    <h5>Max</h5> <span class="mail-desc"><strong><?php echo $_SESSION['username'];?></strong>: Welcome To P-Coin Investment Wallet Cant wait to have you started in this.</span> 
                                                </div>
                                            </a>
                                            
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> See all e-Mails <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Messages -->
                        <!-- Profile -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user"></i></a>
                            <div class="dropdown-menu dropdown-menu-right animated slideInRight">
                                <ul class="dropdown-user">
                                    <li role="separator" class="divider"></li>
									<?php  if (isset($_SESSION['username'])) : ?>
    	                            <p style="color:Green;">Welcome!:<strong><?php echo $_SESSION['username']; ?></strong></p>
                                    <li><a> Profile</a></li>
									<li><a> Name:<?php echo $_SESSION['username']; ?></a></li>
									<li><a> Email:  <?php
                    $user_check_query = "SELECT * FROM users WHERE username='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['email'] === 0){echo   '$0.0' ;} else { echo $row['email']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    ?></a> </li>

                                    <li><a href="#">

									</a></li>
                                    <li><a href="#"> Inbox</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a href="userprofile.php"> Profile Setting</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a a href="index.php?logout='1'" style="color: red;"> Logout</a>
									
    <?php endif ?>
								</li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- End header header -->
        <!-- Left Sidebar  -->
        <div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebar-menu">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-tachometer"></i><span class="hide-menu">Dashboard <span class="label label-rouded label-primary pull-right"></span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                
                            </ul>
                        </li>
                        <li class="nav-label">Teams & Pools</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-columns"></i><span class="hide-menu">Check Team</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="#">Bankers Team</a></li>
                                <li><a href="#">Riskers</a></li>
                                <li><a href="#">Intermediates</a></li>
                                
                            </ul>
                        </li>
                        <li class="nav-label">Chats &amp; Announcements </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-envelope"></i><span class="hide-menu">Mailbox</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="#">Compose</a></li>
                                <li><a href="#">Read</a></li>
                                <li><a href="#">Inbox</a></li>
                            </ul>
                        </li>
                        
                        <li class="nav-label">Features</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-suitcase"></i><span class="hide-menu">Finances <span class="label label-rouded label-danger pull-right"></span></span></a>
						<ul aria-expanded="false" class="collapse">
                                <li><a href="withdraw.php"> Request Withdrawal </a></li>
                                <li><a href="wallet.php"> Transfer Pcoin </a></li>
                                <li><a href="transferus.php"> Transfer USD/D2P </a></li>
                          		<li><a href="loan.php"> Loan </a></li>
                               
                              
                            </ul>
                        </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-wpforms"></i><span class="hide-menu">Affliates</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><button style="background:#3630a3;color:white;" onclick="this.innerHTML='Check Link at the bottom of the page'">Check Your affiliate link </button></li>
                                <li><a href="#">FAQ About our Affiliates</a></li>
                              

                            
                              
                            </ul>
                        </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="ti-wallet m-r-5"></i><span class="hide-menu">Deposit</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="mpesa.php">Deposit With Mpesa</a></li>
                              <li><a href = "pay.php">Deposit With Other Methods</a></li>

                                                            
                 
                            </ul>
							
                        </li>
                        <li class="nav-label">EXTRA</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-book"></i><span class="hide-menu">Start Verification<span class="label label-rouded label-success pull-right">4</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                
                                <li><a href="#" class="has-arrow">Email Vefication <span class="label label-rounded label-success">3</span></a>
                                    <ul aria-expanded="false" class="collapse">
                                        <li><a href="page-login.html">KYC Verification</a></li>
                                        <li><a href="form-validation.php">Profile Update</a></li>
                                        <li><a href="privacy.php">Privacy Policy</a></li>
									</ul>
                                </li>
                                
                            </ul>
                        </li>
                       
                        
                               
                            </ul>
                        </li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- Bread crumb -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">Dashboard</h3>
                    <?php
                    $user_check_query ="SELECT c.username, c.fullname, c.number, l.username, l.email FROM verified c INNER JOIN users l ON l.email = c.email WHERE l.username ='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['number'] === 0){echo   '<button  style="background:#FF0000;color:white;" type="button"> Status:Not Verified!</button>' ;} else { echo '<button  style="background:#008000;color:white;" type="button"> Status:Verified!</button>' ; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    ?>
                    
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
            <!-- End Bread crumb -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row">
                    <div class="col-md-3">
                        <div class="card p-30">
                            <div class="media">
                                <div class="media-left meida media-middle">
                                    <span><i class="ti-bag f-s-40 color-primary"></i></span>
                                </div>
                                <div class="media-body text-right">
                                    <h4>$<?php
											$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, transactions.amount From users INNER JOIN transactions ON users.username = transactions.username WHERE users.username='".$_SESSION['username']."'";
											$dbresult = mysqli_query($db,$sql);
											if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['amount'] === 0){echo   '$0.0' ;} else { echo $row['amount']; }
		
												}
											}
											else
												{
												echo $dbresult;
  }?> </h4>
                                    <p class="m-b-0">Amount Deposited</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="card">
                            <div class="stat-widget-one">
                                <div class="stat-icon dib"><i class="ti-money color-success border-success"></i></div>
                                <div class="stat-content dib">
                                    <div class="stat-text">Digital Assests</div>
                                    <div class="stat-digit text-success"></div>
                                    <a href="#" >
                                    <p class="stat-text">Click To see</p>
</a>
                                </div>
                            </div>
                        </div>
</div>
                    <div class="col-md-3">
                        <div class="card p-30">
                            <div class="media">
                                <div class="media-left meida media-middle">
                                    <span><i class="ti-vector f-s-40 color-warning"></i></span>
                                </div>
                                <div class="media-body text-right">$
									<?
								$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, transactions.amount From users INNER JOIN transactions ON users.username = transactions.username WHERE users.username='".$_SESSION['username']."'";
											$dbresult = mysqli_query($db,$sql);
											if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['amount'] === 0){echo   '$0.0' ;} else { echo $row['amount']*0.2; }
		
												}
											}
											else
												{
												echo $dbresult;
												}
										?>
                                    <p class="m-b-0">Expected Total Profit Earned</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-30">
                            <div class="media">
                                <div class="media-left meida media-middle">
                                    <span><i class="ti-location-pin f-s-40 color-danger"></i></span>
                                </div>
                                <div class="media-body text-right">
                                    <h4></h4>
                                  <a href= "userprofile.php">
                                    <p class="m-b-0">Total Visitors/Affiliates</p>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">

                    <!-- column -->
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><b>P-Coin Investments and Awards Tokken</b></h4>
                                <div class="stat-heading color-primary"></div>
                                <span><img src="coin3.png" alt="homepage" class="dark-logo" /><b></b></span>
                                <p class="media-body text-right">  
                             <h5><b>₱₵ <?php
									$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, pcointokken.amount From users INNER JOIN pcointokken ON users.username = pcointokken.username WHERE users.username='".$_SESSION['username']."'";
									$dbresult = mysqli_query($db,$sql);
									if($dbresult != "zero")
									{
										while($row = $dbresult->fetch_assoc())
										{
			
										if($row['amount'] ===0){echo   '0.000' ;} else { echo $row['amount']; }

										}
									}
									else
										{
										echo $dbresult;}
									?></b></h5>
                                </p>


                                <p class="m-b-0">Wallet Amount</p>

                                        <h4 class="m-b-20">Bitcoin Amount Deposited</h4>
                                        <!-- List style -->
                                        <ul class="list-style-none">
                                       <p> <a ><i class="cc BTC"></i> <b>₿<?php
									$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, btcbalance.amount From users INNER JOIN btcbalance ON users.username = btcbalance.username WHERE users.username='".$_SESSION['username']."'";
									$dbresult = mysqli_query($db,$sql);
									if($dbresult != "zero")
									{
										while($row = $dbresult->fetch_assoc())
										{
			
										if($row['amount'] ===0){echo   '0.000' ;} else { echo $row['amount']; }

										}
									}
									else
										{
										echo $dbresult;}
									?></b></a></p>
                                       <p class="m-b-0">Deposited Amount</p>
                                            
                                        </ul>
                          
                                 <h4 class="m-b-20">Ethereum Amount Deposited</h4>
                                        <!-- List style -->
                                        <ul class="list-style-none">
                                    
                                       <p> <image src=1200px-Ethereum-icon-purple.svg.webp></i><b><?php
									$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, ethbalance.amount From users INNER JOIN ethbalance ON users.username = ethbalance.username WHERE users.username='".$_SESSION['username']."'";
									$dbresult = mysqli_query($db,$sql);
									if($dbresult != "zero")
									{
										while($row = $dbresult->fetch_assoc())
										{
			
										if($row['amount'] ===0){echo   '0.000' ;} else { echo $row['amount']; }

										}
									}
									else
										{
										echo $dbresult;}
									?></b></p>
                                       <p class="m-b-0">Deposited Amount</p>

                                        
                                            
                                       <h4 class="m-b-20">Tether T20 Amount Deposited</h4>
                                        <!-- List style -->
                                        <ul class="list-style-none">
                                       <p> <image src="Tether-USDT-icon.png" style='font-size:24px'><b><?php
									$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, tetherbalance.amount From users INNER JOIN tetherbalance ON users.username = tetherbalance.username WHERE users.username='".$_SESSION['username']."'";
									$dbresult = mysqli_query($db,$sql);
									if($dbresult != "zero")
									{
										while($row = $dbresult->fetch_assoc())
										{
			
										if($row['amount'] ===0){echo   '0.000' ;} else { echo $row['amount']; }

										}
									}
									else
										{
										echo $dbresult;}
									?></b></p>
                                       <p class="m-b-0">Deposited Amount</p>
                                        </ul>
                                    </li>
                                
                                <button  style="background:#3630a3;color:white;" type="button">Check the best performing digital assets:Learn More!</button>
                                

                            </div>
                        </div>
                    </div>
                    <!-- column -->

                    <!-- column -->
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">GPU  Miners Relays</h4>
                                <div id="chartMap"></div>
                            </div>
                        </div>
                    </div>
                    <!-- column -->
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card text-center bg-primary">
                            <div class="m-t-10">
                                <p class="color-white"> Expected Monthly Earnings</p>
                                <h2 class="color-white">$
									<?php
									$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, transactions.amount From users INNER JOIN transactions ON users.username = transactions.username WHERE users.username='".$_SESSION['username']."'";
									$dbresult = mysqli_query($db,$sql);
									if($dbresult != "zero")
									{
										while($row = $dbresult->fetch_assoc())
										{
			
										if($row['amount'] === 0){echo   '$0.0' ;} else { echo $row['amount']*0.2*3.5; }

										}
									}
									else
										{
										echo $dbresult;}
									?>
								</h2>
                            </div>
                            <ul class="widget-line-list m-b-15">
                                <li class="border-right">20% <br><span class="color-white"><i class="ti-hand-point-up m-r-5"></i> Profit</span></li>
                                <li>2% <br><span class="color-white f-s-14"><i class="ti-hand-point-down m-r-5"></i>Deductions</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card text-center bg-success">
                            <div class="m-t-10">
                                <p class="color-white"> Expected Weekly Earnings</p>
                                <h2 class="color-white">$<?php

								$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, transactions.amount From users INNER JOIN transactions ON users.username = transactions.username WHERE users.username='".$_SESSION['username']."'";
											$dbresult = mysqli_query($db,$sql);
											if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['amount'] === 0){echo   '$0.0' ;} else { echo $row['amount']*0.2*1; }
		
												}
											}
											else
												{
													echo $dbresult;}
									?>
								</h2>
                            </div>
                            <ul class="widget-line-list m-b-15">
                                <li class="border-right">20% <br><span class="color-white"><i class="ti-hand-point-up m-r-5"></i> Profit</span></li>
                                <li>2% <br><span class="color-white f-s-14"><i class="ti-hand-point-down m-r-5"></i>Deductions</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card text-center bg-danger">
                            <div class="m-t-10">
                                <p class="color-white">Total Balance</p>
                                <h2 class="color-white">$<?php
                    $user_check_query = "SELECT * FROM balances WHERE username='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['amountb'] === 0){echo   '$0.0' ;} else { echo $row['amountb']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                                                ?>
								</h2>
                            </div>
                            <ul class="widget-line-list m-b-15">
                                <li class="border-right">20% <br><span class="color-white"><i class="ti-hand-point-up m-r-5"></i> Interest Growth</span></li>
                                <li>0% <br><span class="color-white f-s-14"><i class="ti-hand-point-down m-r-5"></i>Depreciation</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Your Device Information</h4>
                                <div class="card-content">
                                    <div class="todo-list">
                                        <div class="tdl-holder">
                                            <div class="tdl-content">
                                                <ul>
                                                    <li class="color-primary">
                                                        <label>
                                                        <input type="checkbox"><i class="bg-primary"></i><span><?php
																														print "Your IP address is ".$_SERVER['REMOTE_ADDR'];
																														?></span>
                                                        <a></a>
                                                    </label>
                                                    </li>
													<li class="color-primary">
                                                        <label>
                                                        <input type="checkbox"><i class="bg-primary"></i><span>Location:<script>
														function getLocation() {
                                                            alert("Hello Buddy , Have you verified your account ??, Get a chance to earn 500 free p-coins on profile update and 1000 free p-coins on KYC Harry!! Click on start verfications to get started , ignore if did.");  
																}</script>

                                                        <a></a>
                                                    </label>
                                                    </li>
                                                    <li class="color-primary">
                                                        <label>
                                                        <input type="checkbox"><i class="bg-primary"></i><span><?php
																														print "Your IP address is ".$_SERVER['REMOTE_ADDR'];
																														?></span>
                                                        <a></a>
                                                    </label>
                                                    </li>
                                                    
                                                    
                                                    </label>
                                                    </li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                   <?php
            $user_check_query = "SELECT * FROM history WHERE username='".$_SESSION['username']."'";
            $dbresult = mysqli_query($db, $user_check_query);
            echo "
            <div class='col-lg-7'>
                        <div class='card'>
                            <div class='card-title'>
                                <h4>Your Transaction History</h4>

                            </div>
                            <div class='card-body'>
                                <div class='table-responsive'>
                                    <table class='table table-bordered'>
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                                <th>Time</th>
                                                <th>Currency</th>
                                                <th>Wallet </th>
                                                

                                            </tr>
                                        </thead>";
                                        if($dbresult != "zero")
                                        {
                                          while($row = $dbresult->fetch_assoc())
                                          {
                            
                                          if($row['amount'] === 0){echo   '$0.0' ;} else {
                                                                      echo "<tr>";
                                                                      echo "<td>" . $row['id'] . "</td>";
                                                                      echo "<td>" . $row['username'] . "</td>";
                                                                      echo "<td class = 'color-success'>".$row['amount'] . "</td>";
                                                                      echo "<td><span class='badge badge-primary'>".$row['Status']."</span></td>";
                                                                      echo "<td>"  . $row['Time'] . "</td>";
                                                                      echo "<td class = 'color-success'>".$row['meansofpay'] . "</td>";
                                                                      echo "<td><span class = 'badge badge-primary'>".$row['wallet'] ."</span></td>";
                                                                      echo "</tr>"; }
                      
                                          }
                                        }
                                        echo "</table>";?>
                                        
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-title">
                                <h4>Our Privacy Policy</h4>
                            </div>
                            <div class="card-body browser">
                                <p> 
                                    We are committed About your privacy , We protect every user data to ensure your private data is protected
                                    Here with our affiliate companies , we make sure that our customers and investors are  able to make the maximum
                                    use of this platform . Our goal is to make this be a sole site to make profitable outcome at a steady rate.
                                </p>
                            <button  style="background:#3630a3;color:white;" type="button">Learn More About Our Privacy Policy</button>
                                
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                    <div class="col-lg-4">
                   
                        <div class="card bg-primary">
                            <div class="weather-widget">
                            <div class="card-title">
                                <h4>Copy the Affiliate Link</h4>
                                                   </div>
                                <div id="weather-one" class="weather-one p-22"></div>
                                <input type="text" class="form-control input-rounded" value="https://pcoin.poltechsolutionsllc.com/referal.php?referer=<?php echo $_SESSION['username']?>" id="myInput"><br>
                                    <button class="btn btn-dark btn-outline m-b-10 m-l-5" onclick="myFunction()">Copy</button>

                                    <script>
                                    function myFunction() {
                                    // Get the text field
                                    var copyText = document.getElementById("myInput");

                                    // Select the text field
                                    copyText.select();
                                    copyText.setSelectionRange(0, 99999); // For mobile devices

                                    // Copy the text inside the text field
                                    navigator.clipboard.writeText(copyText.value);
                                    
                                    // Alert the copied text
                                    alert("Copied the Link: " + copyText.value);
                                    }
                                    </script>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card bg-dark">
                            <div class="testimonial-widget-one p-17">
                                <div class="testimonial-widget-one owl-carousel owl-theme">
                                    
                                    <div class="item">
                                        <div class="testimonial-content">
                                            <img class="testimonial-author-img" src="images/logo.png" alt="" />
                                            <div class="testimonial-author">Max</div>
                                            <div class="testimonial-author-position">P-Coin Admin</div>

                                            <div class="testimonial-text">
                                                <i class="fa fa-quote-left">Dear <?php echo $_SESSION['username'];?> , I know you might be asking yourself what this platform is, Mainly this is an investment based platform and also a crypto wallet. Can be a bank for you too allow your cash to grow. You can work with us through our affliate programs to make sure both sides benefit.</i> 
                                                <i class="fa fa-quote-right"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="testimonial-content">
                                            <img class="testimonial-author-img" src="images/logo.png" alt="" />
                                            <div class="testimonial-author">Max</div>
                                            <div class="testimonial-author-position">P-Coin Admin</div>

                                            <div class="testimonial-text">
                                                <i class="fa fa-quote-left">Dear <?php echo $_SESSION['username'];?> , I know you might be asking yourself what this platform is, Mainly this is an investment based platform and also a crypto wallet. Can be a bank for you too allow your cash to grow. You can work with us through our affliate programs to make sure both sides benefit.</i>
                                                <i class="fa fa-quote-right"></i>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                   
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End PAge Content -->
            </div>
            <!-- End Container fluid  -->
            <!-- footer -->
            <footer class="footer"> © 2022 P-Coin All Right Reserved.</footer>
            <!-- End footer -->
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
	
	<!-- Amchart -->
    <script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
    <script src="js/lib/chart-amchart/serial.js"></script>
    <script src="js/lib/chart-amchart/export.min.js"></script>
    <script src="js/lib/chart-amchart/light.js"></script>
    <script src="js/lib/chart-amchart/ammap.js"></script>
    <script src="js/lib/chart-amchart/worldLow.js"></script>
    <script src="js/lib/chart-amchart/pie.js"></script>
    <script src="js/lib/chart-amchart/amstock.js"></script>
    <script src="js/lib/chart-amchart/amchart-init.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>


    <script src="js/lib/weather/jquery.simpleWeather.min.js"></script>
    <script src="js/lib/weather/weather-init.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel-init.js"></script>
    <script src="js/scripts.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>
<!--  ABOUT AREA END  -->
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
    var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
    s1.async=true;
    s1.src='https://embed.tawk.to/61ed2e7a9bd1f31184d8d464/1fq37r4a3';
    s1.charset='UTF-8';
    s1.setAttribute('crossorigin','*');
    s0.parentNode.insertBefore(s1,s0);
    })();
    </script>
 <script>
        var isNS = (navigator.appName == "Netscape") ? 1 : 0;
        if(navigator.appName == "Netscape") document.captureEvents(Event.MOUSEDOWN||Event.MOUSEUP);
        function mischandler(){
        return false;
        }
        function mousehandler(e){
        var myevent = (isNS) ? e : event;
        var eventbutton = (isNS) ? myevent.which : myevent.button;
        if((eventbutton==2)||(eventbutton==3)) return false;
        }
        document.oncontextmenu = mischandler;
        document.onmousedown = mousehandler;
        document.onmouseup = mousehandler;
        </script>


</body>

</html>