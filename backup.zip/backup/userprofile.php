<?php
 include_once('server.php');
 if (!isset($_SESSION['username'])) {
     $_SESSION['msg'] = "You must log in first";
     header('location: index.php');
 }
 
 if (isset($_GET['logout'])) {
   session_destroy();
   unset($_SESSION['username']);
   header("location: login.php");
 } 
 
 ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!--  This file has been downloaded from bootdey.com @bootdey on twitter -->
    <!--  All snippets are MIT license http://bootdey.com/license -->
    <title>Profile settings -P-Coin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <META http-equiv="Content-Type" content="text/html; charset= ISO-8859-1">
     <link rel="icon" type="image/png" sizes="16x16" href="images/C.png">
	<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container">

      <!-- Breadcrumb -->
      <nav aria-label="breadcrumb" class="main-breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item"><a href="javascript:void(0)">User</a></li>
          <li class="breadcrumb-item active" aria-current="page">Profile Settings</li>
        </ol>
      </nav>
      <!-- /Breadcrumb -->

      <div class="row gutters-sm">
        <div class="col-md-4 d-none d-md-block">
          <div class="card">
            <div class="card-body">
              <nav class="nav flex-column nav-pills nav-gap-y-1">
                <a href="#profile" data-toggle="tab" class="nav-item nav-link has-icon nav-link-faded active">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user mr-2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>Profile Information
                </a>
                <a href="#account" data-toggle="tab" class="nav-item nav-link has-icon nav-link-faded">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-settings mr-2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>Account Settings
                </a>
                <a href="#security" data-toggle="tab" class="nav-item nav-link has-icon nav-link-faded">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shield mr-2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>Security
                </a>
                <a href="#notification" data-toggle="tab" class="nav-item nav-link has-icon nav-link-faded">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell mr-2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>Notification
                </a>
                <a href="#billing" data-toggle="tab" class="nav-item nav-link has-icon nav-link-faded">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-credit-card mr-2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>Payment Methods & Affiliate Data
                </a>
              </nav>
            </div>
          </div>
        </div>
        <div class="col-md-8">
          <div class="card">
            <div class="card-header border-bottom mb-3 d-flex d-md-none">
              <ul class="nav nav-tabs card-header-tabs nav-gap-x-1" role="tablist">
                <li class="nav-item">
                  <a href="#profile" data-toggle="tab" class="nav-link has-icon active"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></a>
                </li>
                <li class="nav-item">
                  <a href="#account" data-toggle="tab" class="nav-link has-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-settings"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></a>
                </li>
                <li class="nav-item">
                  <a href="#security" data-toggle="tab" class="nav-link has-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shield"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg></a>
                </li>
                <li class="nav-item">
                  <a href="#notification" data-toggle="tab" class="nav-link has-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg></a>
                </li>
                <li class="nav-item">
                  <a href="#billing" data-toggle="tab" class="nav-link has-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-credit-card"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg></a>
                </li>
              </ul>
            </div>
            <div class="card-body tab-content">
              <div class="tab-pane active" id="profile">
                <h6>YOUR PROFILE INFORMATION</h6>
                <hr>
                <form>
                <div class="form-group">
                    <label for="fullName">Username</label>
                    <input type="text" class="form-control" id="fullName" aria-describedby="fullNameHelp" placeholder="Enter your fullname" value="<?php echo $_SESSION['username'];?>" readonly>
                    <small id="fullNameHelp" class="form-text text-muted">Your username may appear around here where you are mentioned. You cannot change or remove it at any time.</small>
                  </div>

                  <div class="form-group">
                    <label for="fullName">Fullname</label>
                    <input type="text" class="form-control" id="fullName" aria-describedby="fullNameHelp" placeholder=""  value ="<?php
                    $user_check_query ="SELECT c.username, c.fullname, c.country, l.username, l.email FROM verified c INNER JOIN users l ON l.email = c.email WHERE l.username ='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['fullname'] === 0){echo   '$0.0' ;} else { echo $row['fullname']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    ?> "readonly>
                    <small id="fullNameHelp" class="form-text text-muted">Your fullname may appear around here where you are mentioned. You cannot change or remove it at any time.</small>
                  </div>
                  
                  <div class="form-group">
                  <label for="fullName">Email</label>
                    <input type="text" class="form-control" id="fullName" aria-describedby="fullNameHelp" placeholder="<?php
                    $user_check_query = "SELECT * FROM users WHERE username='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['email'] === 0){echo   '$0.0' ;} else { echo $row['email']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    ?>
                    " value="" readonly>
                    <small id="fullNameHelp" class="form-text text-muted">Your email may appear around here where you are mentioned. You cannot change or remove it at any time.</small>
                  </div>
            
                  <div class="form-group">
                    <label for="bio">Your Bio</label>
                    <textarea class="form-control autosize" id="bio" placeholder="<?php $user_check_query ="SELECT c.username, c.fullname, c.suggestions, l.username, l.email FROM verified c INNER JOIN users l ON l.email = c.email WHERE l.username ='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['suggestions'] === 0){echo   '$0.0' ;} else { echo $row['suggestions']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    ?>" style="overflow: hidden; overflow-wrap: break-word; resize: none; height: 62px;"></textarea>
                  </div>

                  <div class="form-group">
                    <label for="location">Location</label>
                    <input type="text" class="form-control" id="location" placeholder="<?php
                    $user_check_query ="SELECT c.username, c.fullname, c.country, l.username, l.email FROM verified c INNER JOIN users l ON l.email = c.email WHERE l.username ='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['country'] === 0){echo   '$0.0' ;} else { echo $row['country']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    ?>
        
                    " value="" readonly>
                  </div>
                  <div class="form-group small text-muted">
                    All of the fields on this page are  not optional and cannot be deleted at any time, and by filling them out, you're giving us consent to share this data wherever your user profile appears.
                  </div>

                  <div class="form-group">
                    <label for="location">Mobile</label>
                    <input type="text" class="form-control" id="location" placeholder="<?php
                    $user_check_query ="SELECT c.username, c.fullname, c.number, l.username, l.email FROM verified c INNER JOIN users l ON l.email = c.email WHERE l.username ='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['number'] === 0){echo   '$0.0' ;} else { echo $row['number']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    ?>
        
                    " value="" readonly>
                  </div>
                  <div class="form-group small text-muted">
                    All of the fields on this page are  not optional and cannot be deleted at any time, and by filling them out, you're giving us consent to share this data wherever your user profile appears.
                  </div>
                  
                </form>
              </div>
              <div class="tab-pane" id="account">
                <h6>ACCOUNT SETTINGS</h6>
                <hr>
                <form>
                   <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" class="form-control" id="username" aria-describedby="usernameHelp" placeholder="" value="<?php echo $_SESSION['username'];?>" readonly>
                    <small id="usernameHelp" class="form-text text-muted">Your account username will appear here.</small>
                  </div>
                  <div class="form-group">
                    <label for="username">Payment Wallet</label>
                    <input type="text" class="form-control" id="username" aria-describedby="usernameHelp" placeholder="Enter your username" value="<?php 
                    $user_check_query = "SELECT * FROM accountdetails WHERE username='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['walletid'] === 0){echo   '$0.0' ;} else { echo $row['walletid']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    
                    ?>" readonly>
                    <small id="usernameHelp" class="form-text text-muted">Your payment wallet_id will appear here.</small>
                        </div>
                  <div class="form-group">
                    <label for="username">Means of Pay/Wallet Type</label>
                    <input type="text" class="form-control" id="username" aria-describedby="usernameHelp"  placeholder="<?php 
                    $user_check_query = "SELECT * FROM accountdetails WHERE username='".$_SESSION['username']."'";
                    $dbresult = mysqli_query($db, $user_check_query);
                    if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['meansofpay'] === 0){echo   '$0.0' ;} else { echo $row['meansofpay']; }
		
												}
											}
											else
												{
												echo $dbresult;}
                    
                    ?>" readonly>
                    <small id="usernameHelp" class="form-text text-muted">By choosing your wallet type , it identifies specifically where your money will be credited to</small>
                  </div>
                  <hr>
                  <div class="form-group">
                    <label class="d-block text-danger">Delete Account</label>

                    <p class="text-muted font-size-sm">Once you delete your account, there is no going back. Please be certain.</p>
                  </div>

        
                  <button class="btn btn-danger" onclick="myalert()" type="button">Delete Account</button>
                </form>
                <script>
                    function myalert() {
                    alert("We have to verify why you have to delete your account contact support!");
                    }
                </script>
              </div>
              <div class="tab-pane" id="security">
                <h6>SECURITY SETTINGS / CHANGE PASSWORD</h6> 
               
                 <button class="favorite styled"><a href="#"  >Change Password</a> </button>
                <style> 
                .styled {
                            border: 0;
                            line-height: 2.5;
                            padding: 0 15px;
                            font-size: 1rem;
                            text-align: center;
                            color: #fff;
                            text-shadow: 1px 1px 1px #000;
                            border-radius: 10px;
                            background-color: rgba(220, 0, 0, 1);
                            background-image: linear-gradient(to top left,
                                                            rgba(0, 0, 0, .2),
                                                            rgba(0, 0, 0, .2) 30%,
                                                            rgba(0, 0, 0, 0));
                            box-shadow: inset 2px 2px 3px rgba(255, 255, 255, .6),
                                        inset -2px -2px 3px rgba(0, 0, 0, .6);
                        }

                        .styled:hover {
                            background-color: rgba(255, 0, 0, 1);
                        }

                        .styled:active {
                            box-shadow: inset -2px -2px 3px rgba(255, 255, 255, .6),
                                        inset 2px 2px 3px rgba(0, 0, 0, .6);
                        }
                </style>
                

                <hr>
                <form>
                  <div class="form-group">
                    <label class="d-block">Two Factor Authentication</label>
                    <button class="btn btn-info" type="button">Enable two-factor authentication</button>
                    <p class="small text-muted mt-2">Two-factor authentication adds an additional layer of security to your account by requiring more than just a password to log in.</p>
                  </div>
                </form>
                <hr>
                <form>
                  <div class="form-group mb-0">
                    <label class="d-block">Sessions</label>
                    <p class="font-size-sm text-secondary">This is a list of devices that have logged into your account. Revoke any sessions that you do not recognize.</p>
                    <ul class="list-group list-group-sm">
                      <li class="list-group-item has-icon">
                        <div>
                          <h6 class="mb-0"><?php
											print "Your IP address is ".$_SERVER['REMOTE_ADDR'];
																								?></h6>
                          <small class="text-muted">Your current session seen by this IP</small>
                        </div>
                        <button class="btn btn-light btn-sm ml-auto" type="button">More info</button>
                      </li>
                    </ul>
                  </div>
                </form>
              </div>
              <div class="tab-pane" id="notification">
                <h6>NOTIFICATION SETTINGS</h6>
                <hr>
                <form>
                  <div class="form-group">
                    <label class="d-block mb-0">Security Alerts</label>
                    <div class="small text-muted mb-3">Receive security alert notifications via email</div>
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="customCheck1" checked="">
                      <label class="custom-control-label" for="customCheck1">Email each time a vulnerability is found</label>
                    </div>
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="customCheck2" checked="">
                      <label class="custom-control-label" for="customCheck2">Email a digest summary of vulnerability</label>
                    </div>
                  </div>
                  <div class="form-group mb-0">
                    <label class="d-block">SMS Notifications</label>
                    <ul class="list-group list-group-sm">
                      <li class="list-group-item has-icon">
                        Comments
                        <div class="custom-control custom-control-nolabel custom-switch ml-auto">
                          <input type="checkbox" class="custom-control-input" id="customSwitch1" checked="">
                          <label class="custom-control-label" for="customSwitch1"></label>
                        </div>
                      </li>
                      <li class="list-group-item has-icon">
                        Updates From People
                        <div class="custom-control custom-control-nolabel custom-switch ml-auto">
                          <input type="checkbox" class="custom-control-input" id="customSwitch2">
                          <label class="custom-control-label" for="customSwitch2"></label>
                        </div>
                      </li>
                      <li class="list-group-item has-icon">
                        Reminders
                        <div class="custom-control custom-control-nolabel custom-switch ml-auto">
                          <input type="checkbox" class="custom-control-input" id="customSwitch3" checked="">
                          <label class="custom-control-label" for="customSwitch3"></label>
                        </div>
                      </li>
                      <li class="list-group-item has-icon">
                        Events
                        <div class="custom-control custom-control-nolabel custom-switch ml-auto">
                          <input type="checkbox" class="custom-control-input" id="customSwitch4" checked="">
                          <label class="custom-control-label" for="customSwitch4"></label>
                        </div>
                      </li>
                      <li class="list-group-item has-icon">
                        Pages You Follow
                        <div class="custom-control custom-control-nolabel custom-switch ml-auto">
                          <input type="checkbox" class="custom-control-input" id="customSwitch5">
                          <label class="custom-control-label" for="customSwitch5"></label>
                        </div>
                      </li>
                    </ul>
                  </div>
                </form>
              </div>
              <div class="tab-pane" id="billing">
                <h6>BILLING SETTINGS</h6>
                <hr>
                <form action="" method= "post">
                  <div class="form-group">
                    <label class="d-block mb-0">Payment Method</label>
                    <div class="small text-muted mb-3">You have not added a payment method</div>

                     <div>                   
                    <button class="btn btn-info" formaction="account.php" name ="add" type="submit">Add Payment Method</button>
                  </div>
              </form>
                   <div class="form-group mb-0">
                      <label class="d-block">Your Merchant ID</label>
                    <input type="text" class="form-control" id="fullName" aria-describedby="fullNameHelp" placeholder="Enter your fullname" value="<?php
                    $user_check_query = "SELECT * FROM transactions WHERE username = '".$_SESSION['username']."' ";
                    $result = mysqli_query($db, $user_check_query);
                    $user = mysqli_fetch_assoc($result);
                    echo $user['apikey']
                    ?>
                    " readonly>
                    <small id="fullNameHelp" class="form-text text-muted">Your merchant ID will appear here use this for integration with our payment gateway.</small>
                  </div>
                </form>
                      <form action="userprofile.php" method="post" align="center">
                      <input type="submit" class="favorite styled" name="fetch" value="YOUR AFFILIATES DATA" />

                      </form>
                      <?php
                      
                      
                          //mysql_query() performs a single query to the currently active database on the server that is associated with the specified link identifier
                          $sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, transactions.amount From users INNER JOIN transactions ON users.username = transactions.username WHERE users.referer='".$_SESSION['username']."'";
                          $dbresult = mysqli_query($db,$sql);
                          echo "<table border='2' align='center'>
                      <H2 align='center'> YOUR NETWORK </h2>
                      <tr>
                      <th>Email</th>
                      <th>Amount</th>
                      </tr>";
                      if($dbresult != "zero")
                                            {
                                              while($row = $dbresult->fetch_assoc())
                                              {
                                
                                              if($row['amount'] === 0){echo   '$0.0' ;} else {
                                                                          echo "<tr>";
                                                                          echo "<td>" . $row['email'] . "</td>";
                                                                          echo "<td>" . $row['amount'] . "</td>";
                                                                          echo "</tr>"; }
                          
                                              }
                                            }
                                            echo "</table>";
                                                                  
                         
                      ?>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

<style type="text/css">
body{
    margin-top:20px;
    color: #1a202c;
    text-align: left;
    background-color: #070713;    
}
.main-body {
    padding: 15px;
}

.nav-link {
    color: #4a5568;
}
.card {
    box-shadow: 0 1px 3px 0 rgba(0,0,0,.1), 0 1px 2px 0 rgba(0,0,0,.06);
}

.card {
    position: relative;
    display: flex;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 0 solid rgba(0,0,0,.125);
    border-radius: .25rem;
}

.card-body {
    flex: 1 1 auto;
    min-height: 1px;
    padding: 1rem;
}

.gutters-sm {
    margin-right: -8px;
    margin-left: -8px;
}

.gutters-sm>.col, .gutters-sm>[class*=col-] {
    padding-right: 8px;
    padding-left: 8px;
}
.mb-3, .my-3 {
    margin-bottom: 1rem!important;
}

.bg-gray-300 {
    background-color: #e2e8f0;
}
.h-100 {
    height: 100%!important;
}
.shadow-none {
    box-shadow: none!important;
}

</style>

<script type="text/javascript">

</script>
</body>
</html>