<?php include('server.php');
$email    = "";
$errors = array();
if (isset($_POST['reset'])) {
  $email = mysqli_real_escape_string($db, $_POST['email']);
  

  if (empty($email)) {
  	array_push($errors, "Your Email is required");
  }
  if (count($errors) == 0) {
    $query = "SELECT * FROM users WHERE email='$email' ";
    $results = mysqli_query($db, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['email'] = $email;
      ini_set( 'display_errors', 1 );
      error_reporting( E_ALL );
      $from = "epoltech@e-poltechsolutions.com";
      $to = $_SESSION['email'];
      $subject = "Password Reset Link.";
      $message = "Your Password Reset Link Is:https://pcoin.poltechsolutionsllc.com/forgotpas.php?password=$email
           ";
      $headers = "From:" . $from;
      if(mail($to,$subject,$message, $headers)) {
          $email = $_SESSION['email'];
           echo"<p  align = 'center' style='color:green'><strong>Reset Email Sent!!</strong></style>
                    <script type='text/javascript'>
                    window.location = 'login.php';
                    </script> 
                    ";
        }
    }
      else{
        array_push($errors, "Wrong Email, The Email is not associated with any user account");
      }
       
    }
}


?>
<!DOCTYPE html>
<html>
<head>
  <title>P-Coin Investment Wallet Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/png" sizes="16x16" href="images/C.png">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Reset Password</h2>
  </div>
	 
  <form method="post" action="reset.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Email</label>
  		<input type="text" name="email" >
  	</div>
  	
      
  	<div class="input-group">
  		<button type="submit" class="btn" name="reset">Request New Password</button>
  	</div>
  	<p>
  		Back to Login? <a href="register.php">Login</a>
		                  
  	</p>
  </form>


</body>

         
</html>