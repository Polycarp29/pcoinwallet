<?php 
  include('server.php');

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }

  if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['username']);
	header("location: login.php");
} 

?>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <META http-equiv="Content-Type" content="text/html; charset= ISO-8859-1">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="logo.png">
    <title>P-Coin Wallet Investment </title>
<div class="container">
 <div class="card">
        <div class="form">
            <div class="left-side">
                <h3>My Wallet</h3>
                <div class="left_top">
                    <div class="img_sec">
                        <img src="logo.png">
                        <div class="img_text">
                            <h4>Welcome To You P-Coin Wallet </h4>
                            <p>Wallet For Everyone</p>
                        </div>

            <?php
                if(isset($_POST['send'])){
                    $amount = mysqli_real_escape_string($db, $_POST['amount']);
                    $email = mysqli_real_escape_string($db, $_POST['email']);
                

                $user_check_amount = "SELECT * FROM pcointokken WHERE username='".$_SESSION['username']."' OR amount='$amount' LIMIT 1";
                $result = mysqli_query($db, $user_check_amount);
                $user = mysqli_fetch_assoc($result);
                if ($user) { // if user amount is less than 1
                    if ($user['amount'] <1) {
                      echo"<style='color:red'><strong>You cant send What You Dont Have</strong></style>";
                    }

                }
                    // deduct from your amount 
                    $deductions = "UPDATE pcointokken  SET  amount = amount - '$amount' WHERE username = '".$_SESSION['username']."' " ;
                    mysqli_query($db, $deductions);
                    //add to the recieving account
                    $query = "UPDATE pcointokken  SET  amount = amount + '$amount' WHERE email = '$email' ";
                    mysqli_query($db, $query);
                    echo"<style='color:green'><strong>Transaction Successfull</strong></style>";
                    header('location:index.php');
                 }
                ?>
                    </div>
                    <i class="fa fa-long-arrow-right"></i>

                    
                </div>
                <div class="access">
                    <h3>Send/ Sell Your P-Coins </h3>
                    <div class="input_text">
                    <input type="text" class="pass" value="<?php
									$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, pcointokken.amount From users INNER JOIN pcointokken ON users.username = pcointokken.username WHERE users.username='".$_SESSION['username']."'";
									$dbresult = mysqli_query($db,$sql);
									if($dbresult != "zero")
									{
										while($row = $dbresult->fetch_assoc())
										{
			
										if($row['email'] ===0){echo   '0.000' ;} else { echo $row['email']; }

										}
									}
									else
										{
										echo $dbresult;}
									?>" name = "email" readonly>
                    <span><i class="fa fa-eye-slash eyes"></i></span>
            
                <div class="input_text">
                    <input type="text" class="amount"  name ="amount" value="<?php echo $_SESSION['username'] ?>" readonly>
                    <span><i class=""></i></span>
                </div>
                    
                </div>
                    <p>Your Selling Link Will Appear Here.</p>
                </div>
                <div class="input_text">
                    <input type="password" class="pass" readonly>
                    <span><i class="fa fa-eye-slash eyes"></i></span>
                </div>
                <div class="left_last">
                    <p>This Feature is Available for Only Level 4 Investors Send Pcoin Instead </p>
                </div>
                <a target="_blank" class="fcc-btn" href="send.php">Send P-Coins</a> 
                <style>
                    .fcc-btn {
                        background-color: #199319;
                        color: white;
                        padding: 15px 25px;
                        text-decoration: none;
                        }
                    </style>
    
                
            </div>
            <div class="right-side">
                <div class="right_img">
                    <img src="logo.png">
                    <h3><?php echo $_SESSION['username']?></h3>
                    <div class="date_status">
                        <div class="status">
                            <h5>Status : </h5>
                            <span><i class="fa fa-check-circle-o"></i></span>
                        </div>
                        <div class="date">
                            <h5>Date : </h5>
                            <p></p>
                        </div>
                    </div>
                    
                </div>
                <div class="summary">
                    <h3> Your P-Coin Bal </h3>
                    <h4><b>₱₵ <?php
									$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, pcointokken.amount From users INNER JOIN pcointokken ON users.username = pcointokken.username WHERE users.username='".$_SESSION['username']."'";
									$dbresult = mysqli_query($db,$sql);
									if($dbresult != "zero")
									{
										while($row = $dbresult->fetch_assoc())
										{
			
										if($row['amount'] ===0){echo   '0.000' ;} else { echo $row['amount']; }

										}
									}
									else
										{
										echo $dbresult;}
									?></b></h4>
                    <i class="fa fa-angle-up"></i>
                </div>
                <div class="left_top right_top">
                    <div class="img_sec">
                        <img src="pcoin.png">
                        <div class="img_text">
                            <h4>Your Recent Transactions </h4>
                            <p>All Will Appear Here</p>
                        </div>
                    </div>
                    <p>₱₵ #</p>
                    
                </div>
                <div class="right_details">
                    <div class="order_deatils">
                        <h5>Amount Sent : </h5>
                        <p>₱₵ </p>
                    </div>
                    <div class="order_deatils">
                        <h5>Amount Remaining : </h5>
                        <span></span>
                        <p>₱₵  </p>
                    </div>
                    <div class="order_deatils">
                        <h5>Network Fees(5%) : </h5>
                        <p>₱₵ </p>
                    </div>
                </div>
                <div class="summary">
                    <h4>USD BAL</h4>
                    <i class="fa fa-angle-down"></i>
                </div>
                <div class="left_top right_top">
                    <div class="img_sec fig">
                        <span>USD</span>
                        <div class="img_text fig_img">
                            <h4>USD</h4>
                            <p>$
                            <?php 
                                $sql = "SELECT c.username, c.amountb, c.wallet_id, l.username, l.amount FROM balances c INNER JOIN transactions l ON l.username = c.username WHERE c.username ='".$_SESSION['username']."'";
                                $dbresult = mysqli_query($db,$sql);
											if($dbresult != "zero")
											{
												while($row = $dbresult->fetch_assoc())
												{
					
												if($row['amount'] === 0){echo   '$0.0' ;} else { echo $row['amount']*0.03*1+$row['amount']-$row['amountb']; }
		
												}
											}
											else
												{
													echo $dbresult;}
                                ?>
                            </p>
                        </div>
                    </div>
                    <button>Switch To ₱₵</button>
                    
                </div>
                <div class="left_top right_top">
                    <div class="img_sec fig">
                        <span>₱₵ </span>
                        <div class="img_text fig_img">
                            <h4>P-Coin</h4>
                            <p>₱₵ <?php
									$sql = "SELECT CONCAT(users.username,' ',users.email) AS name, users.email, pcointokken.amount From users INNER JOIN pcointokken ON users.username = pcointokken.username WHERE users.username='".$_SESSION['username']."'";
									$dbresult = mysqli_query($db,$sql);
									if($dbresult != "zero")
									{
										while($row = $dbresult->fetch_assoc())
										{
			
										if($row['amount'] ===0){echo   '0.000' ;} else { echo $row['amount']; }

										}
									}
									else
										{
										echo $dbresult;}
									?></p>
                        </div>
                    </div>
                    <button>Switch To USD</button>
                    
                </div>
                <div class="summary">
                    <h4>Waiting Order</h4>
                    <i class="fa fa-angle-up"></i>
                </div>
                <div class="left_top right_top right_h4">
                    <div class="img_sec">
                        <div class="img_text">
                            <h4></h4>
                            <p>The Oder ID will be regenerated every session</p>
                        </div>
                    </div>
                    <p>...</p>
                    
                </div>
                <div class="summary">
                    <h4>Wallet Sent</h4>
                    <i class="fa fa-angle-up"></i>
                </div>
                <div class="left_top right_top right_h4 right_p">
                    <div class="img_sec right_pics">
                        <div class="img_text">
                            <h4>Wallet ID</h4>
                            <p></p>
                        </div>
                    </div>
                    <p><i class="fa fa-arrow-right"></i></p>
                    
                </div>
                <div class="left_top right_top right_h4 right_p">
                    <div class="img_sec right_pics">
                        <i class="fa fa-check-circle-o"></i>
                        <div class="img_text">
                            <h4>Email Status</h4>
                            <p>#</p>
                        </div>
                    </div>
                  
                    
                </div>
                <div class="generate">
                    <button>Generate Invoice</button>
                    <div class="powered">
                        
                        <p>Powered By P-Coin</p>
                    </div>
                </div>

            

            </div>
        </div>
 </div>
</div>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@300&display=swap');
*{
    padding:0;
    margin:0;
    box-sizing:border-box;
}
.container{
    min-height:120vh;
    height:scroll;
    display:flex;
    justify-content:center;
    align-items:center;
    background-color:#070713;
}
.container .card{
     margin:50px 0;
    height:auto;
    width:800px;
    background-color:#f7f7f9;
    position:relative;
    box-shadow:0 15px 30px rgba(0,0,0,0.1);
    font-family: 'Source Sans Pro', sans-serif;
   
    
}
.container .card .form{
    width:100%;
    height:100%;
    display:flex;
}
.container .card .left-side{
    width:50%;
    background-color:#f7f7f9;
    height:100% !important;
     padding:30px;
}
/*left-side-start*/
.left_top{
    margin-top:30px;
    display:flex;
    justify-content:space-between;
}
.img_sec{
    display:flex;
    justify-content:center;
}
.img_sec img{
    width:40px;
}
.img_text{
    margin-left:10px;
}
.img_text p{
    font-size:13px;
    font-weight:800;
    color:#87879a;
}
.access{
    margin-top:30px;
}
.access p{
    margin-top:10px;
    font-size:13px;
    font-weight:600;
}
.input_text{
    margin-top:20px;
    position:relative;
    width:100%;
}
input[type="password"]{
    height:45px;
    width:100%;
    border:none;
    outline:0;
    border-radius:10px;
    padding:5px 10px;
    padding-right:33px;
}
input[type="text"]{
    height:45px;
    width:100%;
    border:none;
    outline:0;
    border-radius:10px;
    padding:5px 10px;
    padding-right:33px;
}
.input_text span{
    display:flex;
    justify-content:center;
    align-items:center;
    height:20px;
    width:20px;
    border-radius:50%;
    border:1px solid #4f4e55;
    position:absolute;
    top:13px;
    right:7px;
   
}
.input_text span .fa-eye-slash{
    margin-top:2px;
     font-size:14px;
     cursor:pointer;
     transition:all 0.5s;
     margin-right:1px;
}
.fa-eye{
    margin-top:2px;
     font-size:14px;
     cursor:pointer;
     transition:all 0.5s;
      margin-right:1px;
}
.left_last{
    margin-top:20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.left_last p{
    font-size:13px;
    color:#8e8fa0;
}
.left_last button{
    height:45px;
    width:50%;
    border:none;
    background-color:#7047eb;
    color:#fff;
    font-size:13px;
    cursor:pointer;
    transition:all 0.5s;
    border-radius:10px;
}
.left_last button:hover{
    background-color:#3d11c1;
}









/*left-side-end*/
.container .card .right-side{
    width:50%;
    background-color:#fff;
    height:100%;
     padding:30px;
}
/*right-side-start*/
.right_img{
    display:flex;
    justify-content:center;
    flex-direction:column;
    align-items:center;
}
.right_img img{
    width:40px;
}
.right_img h3{
    margin-top:10px;
}
.date_status{
    display:flex;
    align-items:center; 
    gap:20px;
    margin-top:10px;
}
.status{
    display:flex;
    gap:10px
}
.status span{
    font-size:13px;
}
.status span i{
    margin-right:5px;
    color:#4fd289;
    font-size:15px;
}
.date{
     display:flex;
    gap:10px;
}
.date p{
    font-size:13px;
}
.summary{
    margin-top:20px;
    height:45px;
    width:100%;
    background-color:#f7f7f9;
    display:flex;
    padding:5px 10px;
    justify-content:space-between;
    align-items:center;
}
.right_top{
    margin-top:20px;
}
.right_top p{
    font-size:13px;
}
.right_details {
    margin-top:20px;
}
.order_deatils{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:10px;
    position:relative;
}
.order_deatils p{
    font-size:13px;
}
.order_deatils span{
    height:20px;
    width:60px;
    background-color:#f7f7f9;
    font-size:13px;
    display:flex;
    justify-content:center;
    align-items:center;
    font-weight:900;
    position:absolute;
    left:70px;
}
.total p{
    font-weight:900;
    font-size:15px;
}
.fig span{
    height:40px;
    width:50px;
    background-color:#f7f7f9;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:13px;
    font-weight:800;
}
.fig_img h4{
    font-size:13px;
}
.right_top button{
    border:none;
    background-color:#7047eb;
    width:70px;
    font-size:12px;
    color:#fff;
    border-radius:7px;
    cursor:pointer;
    transition:all 0.5s;
}
.right_top button:hover{
    background-color:#3d11c1;
}
.right_h4{
    font-size:13px;
}
.right_pics img{
    width:20px;
    height:20px;
}

.right_p p{
    font-size:13px;
    font-weight:800;
  

}
.right_p p i{
   margin-right:5px;
}
.right_pics .fa-check-circle-o{

    color:#4fd289;
    font-size:18px;
    
}
.generate{
    margin-top:30px;
    display:flex;
    justify-content:center;
    align-items:center;
    flex-direction:column;
}
.generate button{
    height:45px;
    width:150px;
    border:none;
    background-color:#7047eb;
    border-radius:9px;
    cursor:pointer;
    transition:all 0.5s;
    color:#fff;
    font-size:13px;
}
.generate button:hover{
    background-color:#3d11c1;
}
.powered{
    margin-top:50px;
    margin-bottom:20px;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:13px;
    color:#87889a;
}
.powered img{
    width:30px;
}
</style>
<script>
var click_eye=document.querySelector(".fa-eye-slash");
var pass_type=document.querySelector(".pass");
var seteye=document.querySelector(".eyes");

click_eye.addEventListener('click',function(){
    if(pass_type.type=="password"){
        pass_type.type="text";
        seteye.classList.remove('fa-eye-slash');
        seteye.classList.add('fa-eye');
    }
    else{
        pass_type.type="password";
        seteye.classList.add('fa-eye-slash');
        seteye.classList.remove('fa-eye');
    }
   
});
</script>