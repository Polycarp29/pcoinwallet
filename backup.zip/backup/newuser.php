<?php

include_once('server.php');
 if (!isset($_SESSION['username'])) {
     $_SESSION['msg'] = "You must log in first";
     header('location: index.php');
 }


$str=mysqli_real_escape_string($db,$_GET["str"]);
  
//select user
$sql_query="SELECT * FROM referral WHERE str='$str'";
$result_set=mysqli_query($db,$sql_query) or die('error');
$user_ref=mysqli_fetch_array($result_set);
$user=$user_ref['user'];

if(!isset($_COOKIE['referral'])) { 

//cookie for visitor
setcookie("referral", $str, time() + (86400 * 7), "/"); // 86400 = 1 day // 86400 * 7 for 7 Days

//page view Counts
$sql = "UPDATE referral SET clicks=clicks+1 WHERE str='$str'";
$result_set=mysqli_query($db,$sql);

}

?>
<?php

if($user_ref == false)
{

echo 'Sorry, the user does not exist.';

}
else
{   
?>

<h2>Welcome to Allwebtuts Blog</h2>
<div class="clearfix">&nbsp;</div>
<p><?php echo $user; ?> Loves Allwebtuts what about you??</p>
<p>Read Our Latest Posts</p>

<div class="clearfix">&nbsp;</div>

<?php
}
?>