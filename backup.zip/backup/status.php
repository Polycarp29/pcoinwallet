<?php
//status.php?id=USER_ID
include('server.php');

if($_GET['id'])
{

//variables
$id=mysqli_real_escape_string($db,$_GET["id"]);

//selecr from database
$sql_query = "SELECT * FROM referral WHERE id='$id'";
$result_set=mysqli_query($db,$sql_query) or die('error');
$ref_row=mysqli_fetch_array($result_set); //fetch the result from table
$count=$ref_row['clicks'];
$user=$ref_row['user'];

}

?>


<?php 
if($ref_row)
{
echo "<p>$user Refer $count Users</p>";
}
else
{
echo "<h1>404 Page boss</h1>";
}
?>